package com.alliance.sam.domain;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = UserRole.class)
public class UserRoleIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
