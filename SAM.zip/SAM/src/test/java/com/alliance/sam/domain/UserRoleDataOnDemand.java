package com.alliance.sam.domain;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = UserRole.class)
public class UserRoleDataOnDemand {
}
