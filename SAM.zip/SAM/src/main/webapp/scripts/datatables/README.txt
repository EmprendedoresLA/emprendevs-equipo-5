Those are javascript files from the following projects:

Datatables
----------

* Version: 1.9.4
* jquery.dataTables.js: uncompressend version
* jquery.dataTables.min.js: minified version
* License: DataTables is available under two licenses:
    GPL v2 license (http://datatables.net/license_gpl2) 
    or a BSD (3-point) license (http://datatables.net/license_bsd)
* Downloaded from: http://datatables.net/download/

Datatables Custom API functions
--------------------------------

Custom API functions (from http://datatables.net/plug-ins/api).
Use 'datatables_init_custom_api_functions' function to load desired functions
by default.
 
NOTE
-----

By default the addon will use the compressed versions, change the reference
to the uncompressed ones in the "load-scripts.tagx" if needed. 